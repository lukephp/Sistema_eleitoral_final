<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
     <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap-theme.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 <script src="bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="sr-only">Trocar</span>
        <span class="sr-only">Trocar</span>
        <span class="sr-only">Tracar</span>
        <span class="sr-only">Tracar</span>
      </button>
      <a class="navbar-brand" href="index.php">Início</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
           <li class="alert-warning"><a href="cadastro_candidatos.php">Cadastro de Candidatos</a></li>
            <li class="alert-info"><a href="Cadastro_eleitor.php">Cadastro de Eleitor</a></li>
            <li class="alert-danger"><a href="consulta_eleitor.php">Consultar Eleitor</a></li>
            <li class="alert-dismissible"><a href="voto.php">Votar</a></li>
            <li class="alert-success"><a href="grafico.php">Resultados</a></li>
      </ul>
     
     
          </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>


</body>
</html>