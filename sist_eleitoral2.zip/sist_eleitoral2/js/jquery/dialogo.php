<link  rel="stylesheet" href="../jquery/jquery/jquery.mobile-1.4.5.css" >
<script src="../jquery/jquery/jquery-1.12.3.min.js"></script>
	<script src="../jquery/jquery/jquery.mobile-1.4.5.min.js"></script>
<body>
	<div data-role="page">
		<div data-role="header">
			<h1>Minha página no JqueryMobale</h1>
		</div><!--/header-->
		<div data-role="content">
			<a href="abas.php" data-rel="dialog" data-transition="pop">Abrir dialogo</a>
		</div><!-- /content-->
		<div data-role="footer"><!--rodape-->
			rodapé
		</div><!-- rodape -->
		</div><!--fim da page 1-->
</body>